export function resolveNextScene(state, choice){
  if(choice?.next?.scene){
    state.meta.currentSceneId = choice.next.scene;
  }
  return state;
}
