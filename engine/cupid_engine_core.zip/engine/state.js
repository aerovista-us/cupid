export const SAVE_KEY = 'cupid_proto_v3_editor';

export function loadState(){
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    return raw ? JSON.parse(raw) : createDefaultState();
  } catch(e){
    return createDefaultState();
  }
}

export function saveState(state){
  localStorage.setItem(SAVE_KEY, JSON.stringify(state));
}

export function createDefaultState(){
  return {
    meta:{ version:1, currentSceneId:'afterparty_apartment', playtimeSec:0 },
    rel:{ stage:'strangers', trust:10, attraction:10, resentment:0, chaos:5 },
    flags:{},
    inventory:{ items:{} },
    missions:{ active:[], progress:{} },
    unlocks:{ scenes:{} },
    log:[]
  };
}
