export function applyEffects(state, effects=[]){
  effects.forEach(e => {
    if(e.type === 'stat.add'){
      const path = e.key.split('.');
      let obj = state;
      while(path.length > 1) obj = obj[path.shift()];
      obj[path[0]] = (obj[path[0]]||0) + e.value;
    }
    if(e.type === 'flag.set') state.flags[e.key] = e.value ?? true;
    if(e.type === 'flag.clear') delete state.flags[e.key];
    if(e.type === 'goto.scene') state.meta.currentSceneId = e.value;
    if(e.type === 'log') state.log.push({ t:Date.now(), msg:e.value });
  });
  return state;
}
