export function computeStage(rel){
  if(rel.resentment >= 80) return 'enemies';
  if(rel.trust >= 80 && rel.attraction >= 75) return 'lovers';
  if(rel.trust >= 60 && rel.attraction >= 40) return 'flirting';
  if(rel.trust < 20 && rel.attraction < 20) return 'strangers';
  return 'situationship';
}

export function evaluateReq(req={}, state){
  if(req.flag){
    for(const f of req.flag) if(!state.flags[f]) return false;
  }
  if(req.notFlag){
    for(const f of req.notFlag) if(state.flags[f]) return false;
  }
  if(req.min){
    for(const k in req.min){
      const val = k.split('.').reduce((o,p)=>o?.[p], state);
      if((val??0) < req.min[k]) return false;
    }
  }
  return true;
}
